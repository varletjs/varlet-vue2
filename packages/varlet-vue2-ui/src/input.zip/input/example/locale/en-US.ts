export default {
  basicUsage: 'Basic Usage',
  plainMode: 'Plain Mode',
  textarea: 'Textarea',
  maxlength: 'Maxlength',
  disabled: 'Disabled',
  readonly: 'Readonly',
  clearable: 'Clearable',
  displayIcon: 'Display Icon',
  validate: 'Validate',
  placeholder: 'Please enter text',
  maxMessage: 'Text length must be greater than 6',
  clearableText: 'Clearable Text',
}
