export default {
  basicUsage: '基本使用',
  plainMode: '朴素模式',
  textarea: '文本域',
  maxlength: '最大长度',
  disabled: '禁用',
  readonly: '只读',
  clearable: '可清除',
  displayIcon: '显示图标',
  validate: '字段校验',
  placeholder: '请输入文本',
  maxMessage: '文本长度必须大于6',
  clearableText: '可清除文本',
}
