export default {
  basicUsage: '基本使用',
  customFormat: '自定义格式',
  showMillisecond: '显示毫秒',
  customStyle: '自定义样式',
  manualControl: '手动控制',
  format: 'DD 天 HH 时 mm 分 ss 秒',
  startText: '开始',
  pauseText: '暂停',
  resetText: '重置',
}
